<!-- src/App.vue -->
<script setup>
import Settings from './components/Settings.vue';


</script>

<template>
  <div>
    <Settings />

  </div>

</template>

<style scoped>
/* Optional global styles */
</style>