<!-- CardFrame.vue -->
<script setup>
const props = defineProps({
  title:  { type: String, required: true },
  dirty:  { type: Boolean, default: false },
  saving: { type: Boolean, default: false }
})
const emit = defineEmits(['save','reset'])
</script>

<template>
  <section
    class="tw-bg-white tw-rounded-2xl tw-border tw-border-[#05291B]/10
           tw-shadow-[0_8px_24px_rgba(5,41,27,0.08)]
           tw-flex tw-flex-col tw-overflow-hidden
           tw-min-h-[65vh] tw-mb-8 tw-pb-6 tw-pl-6 tw-pr-6 tw-mt-24"
  >
    <!-- Header -->
    <header class="tw-flex tw-items-center tw-justify-between tw-p-1 tw-border-b tw-border-[#05291B]/10">
      <div>
        <h2 class="tw-text-lg tw-font-semibold tw-capitalize">{{ title }}</h2>
        <p class="tw-text-xs tw-text-slate-500 tw-italic">Configure {{ title }} options</p>
      </div>
      <el-button
        type="primary"
        class="brand"
        :loading="saving"
        :disabled="!dirty"
        @click="$emit('save')"
      >Save</el-button>
    </header>

    <!-- Scrollable body (only this area scrolls) -->
    <div class="tw-flex-1 tw-overflow-auto tw-p-2">
      <slot />
    </div>

    <!-- Footer (fixed at bottom of the card due to flex layout) -->
    <footer
      class="tw-bg-white tw-border-t tw-border-gray-200
             tw-px-5 tw-pt-3 tw-pb-[27px] tw-flex tw-justify-end tw-gap-2"
    >
      <el-button plain :disabled="!dirty" @click="$emit('reset')">Reset</el-button>
      <el-button
        type="primary"
        class="brand"
        :loading="saving"
        :disabled="!dirty"
        @click="$emit('save')"
      >Save</el-button>
    </footer>
  </section>
</template>

<style scoped>
.brand { --el-color-primary:#05291B; }
</style>
