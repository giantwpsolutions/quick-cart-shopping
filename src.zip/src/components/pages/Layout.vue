<!-- src/components/pages/LayoutSection.vue -->
<script setup>
import { ref, watch } from 'vue'

// import the preview images (Vite will fingerprint + optimize)
import imgDirect from '@/assets/Sidecart.png'
import imgSide   from '@/assets/Sidecart.png'
import imgPopup  from '@/assets/middlecart.png'
console.log('alias test:', imgPopup)

const props = defineProps({ modelValue: { type: Object, required: true } })
const emit  = defineEmits(['update:modelValue'])

const form  = ref({ ...props.modelValue })
watch(() => props.modelValue, v => form.value = { ...v }, { deep: true })

function update(k, v){ form.value[k] = v; emit('update:modelValue', { ...form.value }) }

// cards data
const cartOptions = [
  { key: 'direct', title: 'Direct Checkout', img: imgDirect },
  { key: 'side',   title: 'Side Cart',       img: imgSide   },
  { key: 'popup',  title: 'Popup Cart',      img: imgPopup  },
]
</script>

<template>
  <div class="tw-space-y-8">
    <!-- Cart option -->
    <div>
      <h3 class="tw-font-medium tw-mb-3">Choose cart options</h3>

      <div class="tw-grid sm:tw-grid-cols-3 tw-gap-4">
        <label
          v-for="o in cartOptions"
          :key="o.key"
          :class="[
            'tw-group tw-block tw-rounded-xl tw-border tw-bg-white tw-cursor-pointer',
            'tw-transition tw-shadow-sm hover:tw-shadow',
            form.cartOption===o.key
              ? 'tw-border-[#05291B] tw-ring-2 tw-ring-[#05291B]/20'
              : 'tw-border-[#05291B]/10 hover:tw-border-[#05291B]/30'
          ]"
        >
          <!-- native radio (visually hidden for a11y) -->
          <input
            class="tw-sr-only"
            type="radio"
            name="cartOption"
            :value="o.key"
            :checked="form.cartOption===o.key"
            @change="update('cartOption', o.key)"
          />

          <!-- image -->
          <div class="tw-aspect-[4/3] tw-overflow-hidden tw-rounded-t-xl tw-bg-slate-50">
            <img :src="o.img" :alt="o.title"
                 class="tw-h-full tw-w-full tw-object-cover tw-transition group-hover:tw-scale-[1.02]" />
          </div>

          <!-- title + selected dot -->
          <div class="tw-flex tw-items-center tw-justify-between tw-p-4">
            <div class="tw-text-sm tw-font-medium">{{ o.title }}</div>

            <span
              :class="[
                'tw-inline-flex tw-h-4 tw-w-4 tw-rounded-full tw-border',
                form.cartOption===o.key
                  ? 'tw-bg-[#05291B] tw-border-[#05291B]'
                  : 'tw-border-[#05291B]/30'
              ]"
              aria-hidden="true"
            />
          </div>
        </label>
      </div>
    </div>

    <!-- Mode -->
    <div>
      <h3 class="tw-font-medium tw-mb-3">Choose mode</h3>
      <el-radio-group v-model="form.mode" @change="val=>update('mode',val)">
        <el-radio-button label="light">Light</el-radio-button>
        <el-radio-button label="dark">Dark</el-radio-button>
        <el-radio-button label="glass">Glass</el-radio-button>
        <el-radio-button label="gradient">Gradient</el-radio-button>
      </el-radio-group>
    </div>

    <!-- Layout -->
    <div>
      <h3 class="tw-font-medium tw-mb-3">Choose layout</h3>
      <el-select class="tw-w-64" v-model="form.layout" @change="val=>update('layout', val)">
        <el-option label="Standard" value="standard" />
        <el-option label="Split" value="split" />
        <el-option label="Compact" value="compact" />
      </el-select>
    </div>
  </div>
</template>
