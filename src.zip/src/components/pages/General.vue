<script setup>
import { ref } from 'vue'

// state for the switch
const enableQuickCart = ref(true) // default ON
const enableVarProduct = ref(true) // default ON
const enableDragAndDrop = ref(true) // default OND
const enableDirectCheckout = ref(true) // default OND
</script>

<template>
  <div class="tw-space-y-2">
    <!-- label + switch inline -->
    <div class="tw-flex tw-items-center">
      <h4 class="tw-text-sm tw-font-medium tw-pr-2">{{__("Enable Quick Cart Shopping", "quick-cart-shopping")}}</h4>
      <el-switch
        v-model="enableQuickCart"
        class="ml-2"
        size="large"
        inline-prompt
        active-color="#05291B"
        inactive-color="#d1d5db"
         active-text="Yes"
         inactive-text="No"
      />
    </div>
        <div class="tw-flex tw-items-center ">
      <h4 class="tw-text-sm tw-font-medium tw-pr-2">{{__("Enable popup for variable product", "quick-cart-shopping")}}</h4>
      <el-switch
        v-model="enableVarProduct"
        class="ml-2"
        size="large"
        inline-prompt
        active-color="#05291B"
        inactive-color="#d1d5db"
         active-text="Yes"
         inactive-text="No"
      />
    </div>
            <div class="tw-flex tw-items-center ">
      <h4 class="tw-text-sm tw-font-medium tw-pr-2">{{__("Enable drag and drop cart", "quick-cart-shopping")}}</h4>
      <el-switch
        v-model="enableDragAndDrop"
        class="ml-2"
        size="large"
        inline-prompt
        active-color="#05291B"
        inactive-color="#d1d5db"
         active-text="Yes"
         inactive-text="No"
      />
    </div>

        <div class="tw-flex tw-items-center ">
      <h4 class="tw-text-sm tw-font-medium tw-pr-2">{{__("Enable direct checkout", "quick-cart-shopping")}}</h4>
      <el-switch
        v-model="enableDirectCheckout"
        class="ml-2"
        size="large"
        inline-prompt
        active-color="#05291B"
        inactive-color="#d1d5db"
         active-text="Yes"
         inactive-text="No"
      />
    </div>
  </div>
</template>
