<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter, RouterView } from 'vue-router'
import SidebarNav from './SidebarNav.vue'
import PromoPanel from './PromoPanel.vue'
import { ElMessage } from 'element-plus'

const drawer = ref(false)

// form state stays here; pass with provide/inject or a store later if multiple panels need it
const form = ref({ cartOption: 'side', mode: 'light', layout: 'standard' })

function save() { ElMessage.success('Settings saved') }
function reset() { form.value = { cartOption: 'side', mode: 'light', layout: 'standard' }; ElMessage.info('Reset to defaults') }
function contact() { ElMessage.info('We will reach out shortly!') }

// router-aware active tab
const route = useRoute()
const router = useRouter()
const activeMenu = computed({
  get: () => (route.name ? String(route.name) : 'layout'),
  set: (name) => { if (name && name !== route.name) router.push({ name }) }
})
</script>

<template>
  <div id="quickcart-app" class="tw-min-h-screen tw-bg-[#f8faf9] tw-text-slate-800 ">
    <el-container>
      <el-aside width="260px" class="tw-bg-white tw-sticky fix-adminbar-top tw-h-screen tw-hidden md:tw-block">
        <!-- v-model triggers router push via computed setter -->
        <SidebarNav v-model="activeMenu" />
      </el-aside>

      <el-main class="tw-w-full tw-px-3 md:tw-px-6 tw-py-6">
        <div class="tw-grid tw-grid-cols-1 xl:tw-grid-cols-[1fr_320px] tw-gap-6">
          <!-- Slug changes, no reload -->
          <RouterView :form="form" @save="save" @reset="reset" />
          <PromoPanel @contact="contact" />
        </div>
      </el-main>
    </el-container>

    <!-- mobile actions -->
    <div class="md:tw-hidden tw-fixed tw-bottom-4 tw-inset-x-0 tw-px-4 tw-flex tw-justify-center">
      <div class="tw-bg-white tw-rounded-full tw-shadow-lg tw-border tw-border-[#05291B]/10 tw-p-1 tw-flex tw-gap-1">
        <el-button size="small" class="tw-rounded-full" @click="drawer = true">Menu</el-button>
        <el-button size="small" type="primary" class="tw-rounded-full brand-primary" @click="save">Save</el-button>
      </div>
    </div>

    <!-- mobile drawer -->
    <el-drawer v-model="drawer" size="80%" :with-header="false">
      <SidebarNav v-model="activeMenu" @selected="drawer=false" class="tw-p-2" />
    </el-drawer>
  </div>
</template>

<style scoped>
.brand-primary { --el-color-primary: #05291B; }
</style>
