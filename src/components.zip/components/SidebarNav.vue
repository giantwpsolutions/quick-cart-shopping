<script setup>
const props = defineProps({ modelValue: { type: String, required: true } })
const emit = defineEmits(['update:modelValue','selected'])

const items = [
  { key: 'general', label: 'General' },
  { key: 'layout', label: 'Layout' },
  { key: 'toggle', label: 'Toggle' },
  { key: 'cart', label: 'Cart' },
  { key: 'mini', label: 'Mini Cart' },
  { key: 'design', label: 'Design' },
  { key: 'checkout', label: 'Checkout Editor' },
  { key: 'mobile', label: 'Mobile' },
  { key: 'opt', label: 'Optimization' },
]

function onSelect(idx) {
  emit('update:modelValue', idx)   // triggers router push via computed setter
  emit('selected')
}
</script>

<template>
  <div >
    <!-- header omitted for brevity -->
    <el-menu :default-active="props.modelValue" class="tw-border-0 tw-pt-10" @select="onSelect">
      <el-menu-item v-for="i in items" :key="i.key" :index="i.key">{{ i.label }}</el-menu-item>
    </el-menu>
  </div>
</template>
